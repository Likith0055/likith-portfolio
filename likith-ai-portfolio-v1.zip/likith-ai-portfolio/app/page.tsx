import {
  ArrowRight,
  Github,
  Linkedin,
  Mail,
  MapPin,
  ExternalLink,
  Cpu,
  Database,
  CloudCog,
  Workflow,
  Gauge,
  ShieldCheck,
} from "lucide-react";

const skills = [
  {
    title: "Generative AI & Agents",
    icon: Workflow,
    items: ["LLMs", "Agentic AI", "RAG", "LangGraph", "MCP", "Tool Calling"],
  },
  {
    title: "ML & NLP",
    icon: Cpu,
    items: ["PyTorch", "Hugging Face", "NVIDIA NeMo", "Embeddings", "Reranking"],
  },
  {
    title: "Inference & Serving",
    icon: Gauge,
    items: ["TensorRT-LLM", "Triton", "vLLM", "CUDA", "FlashAttention"],
  },
  {
    title: "Backend & Data",
    icon: Database,
    items: ["FastAPI", "gRPC", "Kafka", "Redis", "PostgreSQL", "Spark"],
  },
  {
    title: "Cloud & MLOps",
    icon: CloudCog,
    items: ["AWS", "Kubernetes", "Docker", "Terraform", "MLflow", "GitHub Actions"],
  },
  {
    title: "Evaluation & Reliability",
    icon: ShieldCheck,
    items: ["LLM Evaluation", "DeepEval", "Observability", "Guardrails", "Tracing"],
  },
];

const projects = [
  {
    name: "EvalForge",
    eyebrow: "FLAGSHIP PROJECT",
    title: "LLM Evaluation & Regression Testing Platform",
    description:
      "Automated evaluation platform for comparing model, prompt, and retrieval configurations across correctness, groundedness, citation accuracy, hallucination rate, latency, and cost.",
    metrics: [
      ["93%", "regressions detected"],
      ["72%", "less manual evaluation"],
      ["<250ms", "P95 API latency"],
      ["50+", "concurrent jobs"],
    ],
    stack: ["Python", "FastAPI", "PyTorch", "MLflow", "PostgreSQL", "Redis", "AWS"],
    featured: true,
  },
  {
    name: "DocuMind",
    eyebrow: "NEXT BUILD",
    title: "Enterprise RAG Knowledge Assistant",
    description:
      "Production-oriented RAG assistant centered on hybrid retrieval, reranking, citations, access control, and measurable retrieval quality.",
    stack: ["RAG", "LangGraph", "FAISS", "FastAPI", "PostgreSQL"],
  },
  {
    name: "OpsPilot",
    eyebrow: "NEXT BUILD",
    title: "Agentic Incident Response Assistant",
    description:
      "Agentic troubleshooting workflow for investigating incidents, calling operational tools, maintaining state, and producing auditable actions.",
    stack: ["Agents", "LangGraph", "MCP", "Observability", "Python"],
  },
  {
    name: "InferScale",
    eyebrow: "NEXT BUILD",
    title: "LLM Inference Benchmarking Platform",
    description:
      "Benchmarking system for throughput, latency, batching, model-serving configurations, and deployment tradeoffs across LLM inference stacks.",
    stack: ["vLLM", "Triton", "TensorRT-LLM", "CUDA", "Docker"],
  },
];

const experience = [
  {
    company: "NVIDIA",
    role: "AI/ML Engineer",
    period: "Mar 2025 — Present",
    text:
      "Production AI systems spanning multi-agent orchestration, enterprise RAG, distributed GPU inference, cloud-native deployment, LLMOps, and observability.",
  },
  {
    company: "Accenture",
    role: "Machine Learning Engineer",
    period: "Oct 2020 — Jul 2024",
    text:
      "Built AI/ML platforms involving RAG, scalable Python services, MLOps, event-driven data pipelines, cloud infrastructure, and enterprise integrations.",
  },
];

export default function Home() {
  return (
    <main>
      <nav className="nav shell">
        <a className="brand" href="#top">LP<span>.</span></a>
        <div className="navLinks">
          <a href="#work">Work</a>
          <a href="#experience">Experience</a>
          <a href="#skills">Skills</a>
          <a href="#contact">Contact</a>
        </div>
        <a className="navCta" href="mailto:likithchilakalapadiprabhu@gmail.com">Let&apos;s talk</a>
      </nav>

      <section className="hero shell" id="top">
        <div className="heroGlow" />
        <p className="kicker"><span className="statusDot" /> AI/ML ENGINEER · SANTA CLARA, CA</p>
        <h1>
          Building AI systems that are
          <span> reliable, scalable, and measurable.</span>
        </h1>
        <p className="heroCopy">
          I design production-grade Generative AI, agentic workflows, RAG systems,
          LLM evaluation platforms, and high-performance inference infrastructure.
        </p>
        <div className="heroActions">
          <a className="primaryBtn" href="#work">View selected work <ArrowRight size={17} /></a>
          <a className="secondaryBtn" href="https://github.com/Likith0055" target="_blank" rel="noreferrer">
            <Github size={17} /> GitHub
          </a>
        </div>
        <div className="heroStats">
          <div><strong>5+</strong><span>Years in AI/ML</span></div>
          <div><strong>34%</strong><span>Inference latency reduction</span></div>
          <div><strong>35K+</strong><span>Enterprise users supported</span></div>
          <div><strong>20+</strong><span>Eval configurations benchmarked</span></div>
        </div>
      </section>

      <section className="section shell" id="work">
        <div className="sectionHeading">
          <div>
            <p className="kicker">SELECTED WORK</p>
            <h2>Projects built around real AI engineering problems.</h2>
          </div>
          <p>Evaluation, retrieval, agents, and inference—not tutorial clones.</p>
        </div>

        <article className="featuredCard">
          <div className="featuredTop">
            <div>
              <p className="projectEyebrow">{projects[0].eyebrow}</p>
              <h3>{projects[0].name}</h3>
              <h4>{projects[0].title}</h4>
            </div>
            <div className="projectIndex">01</div>
          </div>
          <p className="projectDescription">{projects[0].description}</p>
          <div className="metrics">
            {projects[0].metrics?.map(([value, label]) => (
              <div className="metric" key={label}>
                <strong>{value}</strong><span>{label}</span>
              </div>
            ))}
          </div>
          <div className="cardFooter">
            <div className="tags">
              {projects[0].stack.map((tag) => <span key={tag}>{tag}</span>)}
            </div>
            <span className="caseStudy">Case study coming next <ArrowRight size={16} /></span>
          </div>
        </article>

        <div className="projectGrid">
          {projects.slice(1).map((project, i) => (
            <article className="projectCard" key={project.name}>
              <div className="featuredTop">
                <p className="projectEyebrow">{project.eyebrow}</p>
                <div className="projectIndex">0{i + 2}</div>
              </div>
              <h3>{project.name}</h3>
              <h4>{project.title}</h4>
              <p className="projectDescription">{project.description}</p>
              <div className="tags">
                {project.stack.map((tag) => <span key={tag}>{tag}</span>)}
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section shell" id="experience">
        <div className="sectionHeading">
          <div>
            <p className="kicker">EXPERIENCE</p>
            <h2>Production AI from models to infrastructure.</h2>
          </div>
        </div>
        <div className="timeline">
          {experience.map((item) => (
            <div className="timelineItem" key={item.company}>
              <div className="timelineDot" />
              <div className="timelineMeta">
                <strong>{item.company}</strong>
                <span>{item.period}</span>
              </div>
              <div>
                <h3>{item.role}</h3>
                <p>{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="section shell" id="skills">
        <div className="sectionHeading">
          <div>
            <p className="kicker">TECHNICAL STACK</p>
            <h2>Focused on the production AI lifecycle.</h2>
          </div>
        </div>
        <div className="skillGrid">
          {skills.map(({ title, icon: Icon, items }) => (
            <article className="skillCard" key={title}>
              <Icon size={22} />
              <h3>{title}</h3>
              <p>{items.join(" · ")}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section shell credentials">
        <div>
          <p className="kicker">EDUCATION</p>
          <h3>Master of Science in Computer Science</h3>
          <p>University at Buffalo, New York</p>
          <h3 className="secondCredential">Bachelor of Technology in Software Engineering</h3>
          <p>Vellore Institute of Technology</p>
        </div>
        <div>
          <p className="kicker">CERTIFICATIONS</p>
          <ul>
            <li>NVIDIA Certified Associate — Generative AI LLMs</li>
            <li>AWS Certified Machine Learning Engineer — Associate</li>
            <li>Databricks Certified Generative AI Engineer Associate</li>
            <li>Certified Kubernetes Administrator (CKA)</li>
          </ul>
        </div>
      </section>

      <section className="contact shell" id="contact">
        <p className="kicker">CONTACT</p>
        <h2>Interested in building production AI systems?</h2>
        <p>Open to AI/ML engineering opportunities and technically ambitious teams.</p>
        <div className="heroActions">
          <a className="primaryBtn" href="mailto:likithchilakalapadiprabhu@gmail.com">
            <Mail size={17} /> Email me
          </a>
          <a className="secondaryBtn" href="https://linkedin.com/in/likith-chilakalapadiprabhu/" target="_blank" rel="noreferrer">
            <Linkedin size={17} /> LinkedIn
          </a>
        </div>
      </section>

      <footer className="footer shell">
        <span>© 2026 Likith Chilakalapadi Prabhu</span>
        <span className="footerLocation"><MapPin size={14} /> Santa Clara, CA</span>
      </footer>
    </main>
  );
}
